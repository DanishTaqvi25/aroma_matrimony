<div style="background-color:#000; border-top:solid 1px #666; max-height:70px; margin-left:0px; margin-right:0px; margin-bottom:0px; padding-left:20px; padding-right:20px; padding-top:20px; color:#ffc107; font-size:16px;">
    <div class="row" style="width:100%;">
    <div class="col-md-6" style="text-align:left; width:50%; float:left;">	
&copy; Lazza Ice Creams - 2022<br />&nbsp;
</div>
    
    <div class="col-md-6" style="text-align:right; width:50%; float:right;">
Site Powered By <a href="https://www.igensoftware.com" target="_blank" style="color:#ffc107">
Igen Software Solutions<br />&nbsp;</a>
</div>
    </div>
    </div>
